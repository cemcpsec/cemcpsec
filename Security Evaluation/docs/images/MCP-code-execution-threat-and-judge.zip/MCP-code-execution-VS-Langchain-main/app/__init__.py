"""
Main application package for MCP Code Execution
"""

