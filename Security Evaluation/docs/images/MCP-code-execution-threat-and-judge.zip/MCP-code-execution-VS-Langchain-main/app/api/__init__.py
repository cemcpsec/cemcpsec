"""
FastAPI application module for MCP benchmark comparison.
"""

