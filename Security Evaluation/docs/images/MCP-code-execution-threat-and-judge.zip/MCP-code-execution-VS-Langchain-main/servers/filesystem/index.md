# MCP Tools — filesystem

Read a tool file before calling it.

- `read_text_file.md`
- `read_media_file.md`
- `read_multiple_files.md`
- `write_file.md`
- `edit_file.md`
- `create_directory.md`
- `list_directory.md`
- `list_directory_with_sizes.md`
- `directory_tree.md`
- `move_file.md`
- `search_files.md`
- `get_file_info.md`
- `list_allowed_directories.md`