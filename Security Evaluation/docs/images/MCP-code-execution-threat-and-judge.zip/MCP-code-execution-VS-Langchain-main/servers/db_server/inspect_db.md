# db_server.inspect_db

Safely inspects the database schema and structure

## Input Schema
```json
{
  "properties": {},
  "type": "object"
}
```

## Example Usage
```python
mcp_call_http(name="db_server.inspect_db", args={})
```
