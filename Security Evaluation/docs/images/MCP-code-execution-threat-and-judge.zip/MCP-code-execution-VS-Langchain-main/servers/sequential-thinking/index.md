# MCP Tools — sequential-thinking

Read a tool file before calling it.

- `sequentialthinking.md`